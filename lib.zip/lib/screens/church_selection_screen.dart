import 'package:flutter/material.dart';
import 'home_screen.dart';

// 1. (Opcional, mas recomendado) Crie uma classe para modelar os dados.
class ChurchProfile {
  final String title;
  final IconData icon;

  const ChurchProfile({required this.title, required this.icon});
}

class ChurchSelectionScreen extends StatelessWidget {
  const ChurchSelectionScreen({super.key});

  // 2. Crie a lista de perfis de igreja aqui.
  // Fica mais fácil adicionar, remover ou reordenar igrejas no futuro.
  final List<ChurchProfile> churchProfiles = const [
    ChurchProfile(title: 'Igreja 1', icon: Icons.church),
    ChurchProfile(title: 'Igreja 2', icon: Icons.book),
    ChurchProfile(title: 'Igreja 3', icon: Icons.groups),
    ChurchProfile(title: 'Igreja 4', icon: Icons.waving_hand),
  ];

  @override
  Widget build(BuildContext context) {
    // A função auxiliar continua útil!
    Widget buildChurchProfileCard({
      required IconData icon,
      required String title,
      required VoidCallback onTap,
    }) {
      return Card(
        elevation: 4.0,
        margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0), // Ajuste de margem
        child: ListTile(
          leading: Icon(icon, size: 40, color: Theme.of(context).primaryColor),
          title: Text(title, style: const TextStyle(fontSize: 18)),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: onTap,
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Selecione o Perfil'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Pesquisar Perfil',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ),
            const SizedBox(height: 40),
            const Text(
              'Ou selecione um dos perfis abaixo:',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w300),
            ),
            const SizedBox(height: 20),

            // 3. Substitua os widgets manuais por um ListView.builder
            Expanded(
              child: ListView.builder(
                itemCount: churchProfiles.length,
                itemBuilder: (context, index) {
                  // Pega o perfil atual da lista
                  final church = churchProfiles[index];
                  
                  // Retorna o card para o perfil atual
                  return buildChurchProfileCard(
                    icon: church.icon,
                    title: church.title,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          // Passa o título do perfil para a HomeScreen
                          builder: (context) => HomeScreen(churchType: church.title),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}